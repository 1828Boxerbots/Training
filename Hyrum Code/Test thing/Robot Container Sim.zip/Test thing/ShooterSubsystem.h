#pragma once
class ShooterSubsystem
{
public:
	ShooterSubsystem();
	void Shoot();
};

