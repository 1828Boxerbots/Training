#include "ShooterSubsystem.h"

ShooterSubsystem::ShooterSubsystem()
{
}

void ShooterSubsystem::Shoot()
{
}
