#include "Vector.h"

Vector::Vector(int port)
{

}

int Vector::Set(double input)
{
    return 0;
}
