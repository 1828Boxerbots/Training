#include "CameraSubsystem.h"

CameraSubsystem::CameraSubsystem()
{
}

int CameraSubsystem::GetBlob()
{
	return 0;
}
