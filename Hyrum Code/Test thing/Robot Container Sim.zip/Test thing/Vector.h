#pragma once
class Vector
{
public:
	Vector(int port);
	int Set(double input);
};

