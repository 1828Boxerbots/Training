#include "Lidar.h"

Lidar::Lidar(int port)
{
}

double Lidar::GetDistance()
{
    return 0.0;
}
