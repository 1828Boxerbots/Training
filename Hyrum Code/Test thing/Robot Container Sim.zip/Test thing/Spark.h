#pragma once
class Spark
{
public:
	Spark(int port);
	int Set(double input);
};

