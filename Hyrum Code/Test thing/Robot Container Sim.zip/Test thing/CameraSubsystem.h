#pragma once
class CameraSubsystem
{
public:
	CameraSubsystem();
	int GetBlob();
};

