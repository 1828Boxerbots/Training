#pragma once

constexpr int PWM_PORT_DRIVE_RIGHT_MOTOR_1 = 1;
constexpr int PWM_PORT_DRIVE_RIGHT_MOTOR_2 = 2;
constexpr int PWM_PORT_DRIVE_LEFT_MOTOR_1 = 3;
constexpr int PWM_PORT_DRIVE_LEFT_MOTOR_2 = 4;
constexpr int PWM_PORT_LOADER_RIGHT_MOTOR = 5;
constexpr int PWM_PORT_LOADER_LEFT_MOTOR = 6;
constexpr int PWM_PORT_SHOOTER_MOTOR = 7;
