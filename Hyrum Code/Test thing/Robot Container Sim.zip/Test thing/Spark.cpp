#include "Spark.h"

Spark::Spark(int port)
{

}

int Spark::Set(double input)
{
	return 0;
}
