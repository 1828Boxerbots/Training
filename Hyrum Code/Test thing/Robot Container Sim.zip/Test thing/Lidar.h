#pragma once
class Lidar
{
public:
	Lidar(int port);
	double GetDistance();
};

